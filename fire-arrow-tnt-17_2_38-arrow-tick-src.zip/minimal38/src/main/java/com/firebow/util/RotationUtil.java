package com.firebow.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Silent rotation cho pattern 2 tick.
 *
 * tick N     (arrow tick): setPendingTarget → lưu hitVec + góc gốc
 * tick N+1   HEAD sendMovementPackets: applyBeforeSync → góc từ eyePos hiện tại → applied = true
 * tick N+1   END: InteractionUtil.executeRail đọc applied → interact → restoreAfterInteract
 * cuối mỗi END_CLIENT_TICK: endOfTick() → applied chỉ sống trong đúng 1 tick
 */
public final class RotationUtil {
    private RotationUtil() {}

    private static volatile Vec3d   pendingHitVec = null;
    private static volatile float   savedYaw      = 0f;
    private static volatile float   savedPitch    = 0f;
    private static volatile boolean applied       = false;

    public static void setPendingTarget(ClientPlayerEntity player, Vec3d hitVec) {
        savedYaw      = player.getYaw();
        savedPitch    = player.getPitch();
        pendingHitVec = hitVec;
        applied       = false;
    }

    public static boolean hasPendingTarget() { return pendingHitVec != null; }

    /** true chỉ khi beforeSync đã áp góc cho tick hiện tại. */
    public static boolean wasApplied() { return applied && pendingHitVec != null; }

    /** Tính góc từ eyePos hiện tại (sau knockback/di chuyển) và áp lên player. */
    public static boolean applyBeforeSync(ClientPlayerEntity player) {
        if (pendingHitVec == null) return false;
        float[] rot = snapToMouseGrid(player, calcRotationFromEye(player.getEyePos(), pendingHitVec));
        applyRaw(player, rot);
        applied = true;
        return true;
    }

    public static void restoreAfterInteract(ClientPlayerEntity player) {
        pendingHitVec = null;
        applied       = false;
        if (player != null) applyRaw(player, new float[]{ savedYaw, savedPitch });
    }

    /** Bỏ target đang chờ và trả lại góc nhìn gốc. An toàn khi gọi nhiều lần. */
    public static void abort(ClientPlayerEntity player) {
        if (pendingHitVec != null) restoreAfterInteract(player);
        else applied = false;
    }

    public static void endOfTick() { applied = false; }

    // ─── KeyboardInputMixin ──────────────────────────────────────────────────

    public static float[] getPendingRot(ClientPlayerEntity player) {
        if (pendingHitVec == null) return null;
        return snapToMouseGrid(player, calcRotationFromEye(player.getEyePos(), pendingHitVec));
    }

    // ─── Math utils ──────────────────────────────────────────────────────────

    public static float[] calcRotation(ClientPlayerEntity player, Vec3d target) {
        return calcRotationFromEye(player.getEyePos(), target);
    }

    /** Bước góc nhỏ nhất chuột vanilla tạo ra ở sensitivity hiện tại. */
    public static double mouseStep() {
        double sens = MinecraftClient.getInstance().options.getMouseSensitivity().getValue();
        double f = sens * 0.6 + 0.2;
        return f * f * f * 8.0 * 0.15;
    }

    /**
     * Snap góc về lưới chuột, delta tính từ góc hiện tại của player.
     * AimModulo360 bắt yaw/pitch đổi không phải bội số bước chuột.
     */
    public static float[] snapToMouseGrid(ClientPlayerEntity player, float[] rot) {
        double step   = mouseStep();
        double curYaw = player.getYaw();
        double curPit = player.getPitch();

        double dYaw   = wrap180(rot[0] - curYaw);
        double dPitch = rot[1] - curPit;

        double yaw   = curYaw + Math.round(dYaw   / step) * step;
        double pitch = curPit + Math.round(dPitch / step) * step;

        double maxPitch = Math.floor(90.0 / step) * step;
        pitch = Math.max(-maxPitch, Math.min(maxPitch, pitch));

        return new float[]{ (float) yaw, (float) pitch };
    }

    private static double wrap180(double deg) {
        return ((deg % 360.0) + 540.0) % 360.0 - 180.0;
    }

    public static float[] calcRotationFromEye(Vec3d eye, Vec3d target) {
        double dx   = target.x - eye.x;
        double dy   = target.y - eye.y;
        double dz   = target.z - eye.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float  yaw  = (float)  Math.toDegrees(Math.atan2(-dx, dz));
        float  pitch= (float) -Math.toDegrees(Math.atan2(dy, dist));
        return new float[]{ yaw, pitch };
    }

    public static Vec3d calcHitVec(BlockPos pos, Direction face) {
        return Vec3d.ofCenter(pos).add(
            face.getOffsetX() * 0.4999,
            face.getOffsetY() * 0.4999,
            face.getOffsetZ() * 0.4999
        );
    }

    public static void applyRaw(ClientPlayerEntity player, float[] rot) {
        player.setYaw(rot[0]);
        player.setPitch(rot[1]);
        player.headYaw = rot[0];
        player.bodyYaw = rot[0];
    }
}
